For the latest information about ZooKeeper, please visit our website at:

   http://hadoop.apache.org/zookeeper/

and our wiki, at:

   http://wiki.apache.org/hadoop/ZooKeeper

Full documentation for this release can also be found in docs/index.html
