Folowing is the list of external jars contained in this directory and the sources from where they were obtained:
---------------------------------------------------------------------------------------------------------------

* jline-0.9.94.jar - http://jline.sourceforge.net/
